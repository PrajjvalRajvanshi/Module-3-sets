package com.cg.dao;

import java.util.List;

import com.cg.dto.Hotel;

public interface IHotelDAO {
	List<Hotel> displayAllHotels();
}

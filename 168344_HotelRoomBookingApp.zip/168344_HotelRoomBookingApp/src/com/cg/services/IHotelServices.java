package com.cg.services;

import java.util.List;

import com.cg.dto.Hotel;

public interface IHotelServices {
	List<Hotel> displayAllHotels();
}

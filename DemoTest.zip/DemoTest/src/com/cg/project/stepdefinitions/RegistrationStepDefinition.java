package com.cg.project.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.pagebeans.Registration;


import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	
	private WebDriver driver;

	private Registration bean;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}
	
	@Given("^User is accessing RegsitrationPage on Browser$")
	public void user_is_accessing_RegsitrationPage_on_Browser() throws Throwable {
		driver.get("D:\\3000131_Prajjval_Rajvanshi\\BDDCucumberSelenium\\WebPages\\text.html");
		bean = PageFactory.initElements(driver, Registration.class);
	}

	@When("^user is trying submit data without entering 'Name'$")
	public void user_is_trying_submit_data_without_entering_Name() throws Throwable {
		bean.signUp();
	}

	@Then("^'Please enter your name\\.' alert message should display$")
	public void please_enter_your_name_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please enter your name.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	
	}
	
	@When("^User is trying to submit request without entring 'Address'$")
	public void user_is_trying_to_submit_request_without_entring_Address() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setName("Prince");
		bean.signUp();
	}

	@Then("^'Please enter your address\\.' alert message should display$")
	public void please_enter_your_address_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please enter your address.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}


	@When("^User is trying to submit request without entering  valid 'email'$")
	public void user_is_trying_to_submit_request_without_entering_valid_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setName("Prince");
		bean.setAddress("Pune");
		bean.signUp();
	}

	@Then("^'Please enter a valid e-mail address\\.' alert message should display$")
	public void please_enter_a_valid_e_mail_address_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please enter a valid e-mail address.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without selecting  valid 'telephone'$")
	public void user_is_trying_to_submit_request_without_selecting_valid_telephone() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setName("Prince");
		bean.setAddress("Pune");
		bean.setEmail("prince@gmail.com");
		bean.signUp();
	}

	@Then("^'Please enter your telephone number\\.' alert message should display$")
	public void please_enter_your_telephone_number_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please enter your telephone number.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is trying to submit request without entring   valid 'Course'$")
	public void user_is_trying_to_submit_request_without_entring_valid_Course() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setName("Prince");
		bean.setAddress("Pune");
		bean.setEmail("prince@gmail.com");
		bean.setTelephone("4328324231");
		bean.signUp();
	}

	@Then("^'Please enter your course\\.' alert message should display$")
	public void please_enter_your_course_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Please enter your course.";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@Given("^User is accing RegistrationPage on Borwser$")
	public void user_is_accing_RegistrationPage_on_Borwser() throws Throwable {
		driver.get("D:\\3000131_Prajjval_Rajvanshi\\BDDCucumberSelenium\\WebPages\\text.html");
		bean = PageFactory.initElements(driver, Registration.class);
	}


	@When("^User is trying to submit request after entering valid set of information$")
	public void user_is_trying_to_submit_request_after_entering_valid_set_of_information() throws Throwable {
		bean.setName("Prince");
		bean.setAddress("Pune");
		bean.setEmail("prince@gmail.com");
		bean.setTelephone("4328324231");
		bean.setSubject("BTECH");
		bean.signUp();
	}

	@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile' alert message should display$")
	public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile_alert_message_should_display() throws Throwable {
		String expectedAlertMessage ="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}
	@After
	public void tearDownStepEnv() {
		driver.close();
	}
}
